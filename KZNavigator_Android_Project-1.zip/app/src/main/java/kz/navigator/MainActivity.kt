package kz.navigator

import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var destinationInput: EditText
    private lateinit var status: TextView
    private var myLocationOverlay: MyLocationNewOverlay? = null
    private var routeLine: Polyline? = null
    private var destinationMarker: Marker? = null
    private var currentLocation: GeoPoint? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = packageName
        buildScreen()
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.controller.setZoom(12.0)
        // Default view: Almaty. The map follows the user's GPS after permission is granted.
        map.controller.setCenter(GeoPoint(43.2383, 76.9455))
        requestLocation()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101820.toInt())
        }
        val header = TextView(this).apply {
            text = "KZ NAVIGATOR"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(18, 16, 18, 12)
            setBackgroundColor(0xFF101820.toInt())
        }
        root.addView(header)
        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(10, 4, 10, 8)
            gravity = Gravity.CENTER_VERTICAL
        }
        destinationInput = EditText(this).apply {
            hint = "Куда направляемся?"
            textSize = 15f
            singleLine = true
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9BA8B3.toInt())
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF263541.toInt())
        }
        searchRow.addView(destinationInput, LinearLayout.LayoutParams(0, 52, 1f))
        val routeButton = Button(this).apply {
            text = "Маршрут"
            setOnClickListener { buildRoute() }
        }
        searchRow.addView(routeButton)
        root.addView(searchRow)
        map = MapView(this)
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 6, 12, 6)
            setBackgroundColor(0xFF101820.toInt())
        }
        status = TextView(this).apply {
            text = "Карта Казахстана • GPS не подключён"
            textSize = 12f
            setTextColor(0xFFDCE5EB.toInt())
        }
        footer.addView(status, LinearLayout.LayoutParams(0, 44, 1f))
        val gpsButton = Button(this).apply {
            text = "Моё место"
            setOnClickListener { centerOnMe() }
        }
        footer.addView(gpsButton)
        root.addView(footer)
        setContentView(root)
    }

    private fun requestLocation() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED && coarse != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
            return
        }
        enableLocation()
    }

    private fun enableLocation() {
        try {
            myLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), map).also {
                it.enableMyLocation()
                it.enableFollowLocation()
                map.overlays.add(it)
            }
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val loc: Location? = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (loc != null) {
                currentLocation = GeoPoint(loc.latitude, loc.longitude)
                map.controller.animateTo(currentLocation)
                status.text = "GPS определён • ${"%.5f".format(loc.latitude)}, ${"%.5f".format(loc.longitude)}"
            } else {
                status.text = "Ожидание GPS • карта открыта"
            }
        } catch (_: SecurityException) {
            status.text = "Нет разрешения на геолокацию"
        } catch (_: Exception) {
            status.text = "GPS пока недоступен"
        }
        map.invalidate()
    }

    private fun centerOnMe() {
        val p = myLocationOverlay?.myLocation
        if (p != null) {
            currentLocation = p
            map.controller.animateTo(p)
            map.controller.setZoom(16.0)
        } else {
            Toast.makeText(this, "Местоположение пока не определено", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buildRoute() {
        val query = destinationInput.text.toString().trim()
        if (query.isEmpty()) {
            destinationInput.error = "Введите адрес или место"
            return
        }
        val origin = myLocationOverlay?.myLocation ?: currentLocation
        if (origin == null) {
            Toast.makeText(this, "Сначала дождитесь определения GPS", Toast.LENGTH_LONG).show()
            return
        }
        status.text = "Поиск адреса…"
        thread {
            try {
                val geocoder = Geocoder(this)
                @Suppress("DEPRECATION")
                val results = geocoder.getFromLocationName(query, 1)
                val found = results?.firstOrNull()
                if (found == null) throw Exception("Адрес не найден")
                val dest = GeoPoint(found.latitude, found.longitude)
                val url = "https://router.project-osrm.org/route/v1/driving/" +
                    "${origin.longitude},${origin.latitude};${dest.longitude},${dest.latitude}" +
                    "?overview=full&geometries=geojson"
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.setRequestProperty("User-Agent", "KZNavigator/0.1")
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val route = JSONObject(body).getJSONArray("routes").getJSONObject(0)
                val distanceKm = route.getDouble("distance") / 1000.0
                val durationMin = route.getDouble("duration") / 60.0
                val coords = route.getJSONObject("geometry").getJSONArray("coordinates")
                val points = ArrayList<GeoPoint>()
                for (i in 0 until coords.length()) {
                    val c = coords.getJSONArray(i)
                    points.add(GeoPoint(c.getDouble(1), c.getDouble(0)))
                }
                runOnUiThread {
                    routeLine?.let { map.overlays.remove(it) }
                    destinationMarker?.let { map.overlays.remove(it) }
                    routeLine = Polyline().apply {
                        setPoints(points)
                        outlinePaint.color = 0xFF20C997.toInt()
                        outlinePaint.strokeWidth = 12f
                    }
                    map.overlays.add(routeLine)
                    destinationMarker = Marker(map).apply {
                        position = dest
                        title = found.getAddressLine(0) ?: query
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    }
                    map.overlays.add(destinationMarker)
                    val bounds = org.osmdroid.util.BoundingBox.fromGeoPoints(points)
                    map.zoomToBoundingBox(bounds, true, 70)
                    status.text = "Маршрут: ${"%.1f".format(distanceKm)} км • около ${durationMin.toInt()} мин"
                    map.invalidate()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Не удалось построить маршрут"
                    Toast.makeText(this, e.message ?: "Ошибка маршрута", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) enableLocation()
    }

    override fun onResume() {
        super.onResume()
        if (::map.isInitialized) map.onResume()
        myLocationOverlay?.enableMyLocation()
    }

    override fun onPause() {
        myLocationOverlay?.disableMyLocation()
        if (::map.isInitialized) map.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        if (::map.isInitialized) map.onDetach()
        super.onDestroy()
    }
}
